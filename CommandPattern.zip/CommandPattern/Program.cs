﻿
RcVehicle rcVehicle = new RcVehicle();
ICommand goForwardCommand = new GoForwardCommand(rcVehicle);
ICommand goBackwardCommand = new GoBackwardCommand(rcVehicle);

RemoteControl remoteControl = new RemoteControl();

remoteControl.setCommand(goForwardCommand);
remoteControl.pressButton();
remoteControl.setCommand(goBackwardCommand);
remoteControl.pressButton();
public class RcVehicle
{

    public void goForward()
    {
        Console.WriteLine("going forward");
    }

    public void goBackward()
    {
        Console.WriteLine("going backward");
    }

}

public interface ICommand
{
    void Execute();
}

public class GoForwardCommand : ICommand
{
    private RcVehicle _rcVehicle;
    public GoForwardCommand(RcVehicle rcVehicle)
    {
        _rcVehicle = rcVehicle;
    }

    public void Execute()
    {
        _rcVehicle.goForward();
    }
}

public class GoBackwardCommand : ICommand
{
    private RcVehicle _rcVehicle;
    public GoBackwardCommand(RcVehicle rcVehicle)
    {
        _rcVehicle = rcVehicle;
    }

    public void Execute()
    {
        _rcVehicle.goBackward();
    }
}

public class RemoteControl
{
    private ICommand _command;


    public void setCommand(ICommand command)
    {
        _command = command;
    }
    public void pressButton()
    {
        _command.Execute();
    }
}

